# include "config.h"
int count=0;
void __interrupt() my_isr(void)
{
    if(INTCONbits.TMR0IF == 1)
    {
        INTCONbits.TMR0IF=0;
       /* count++;
        if(count >= 76)
        {
            PORTD=~PORTD;
            count=0;
        }
        */
        PORTD=~PORTD;
    }
}

void main()
{
    TRISD=0x00;
    PORTD=0x00;
    INTCONbits.GIE=1; //enable global interrupt
    INTCONbits.PEIE=1;//enable peripheral interrupa
    INTCONbits.TMR0IE=1;//enable timer one interrupt
    INTCONbits.TMR0IF=0;//clear the interrupt flag
    ei();
    //configuret the timer 1 with option resgister
    OPTION_REGbits.T0CS=0;//internal instruction cycle clock
    OPTION_REGbits.T0SE=0;//edege selsect 
    OPTION_REGbits.PSA=1;//prescalar assigned to timer 0
    //select the prescalar as 1:256
    OPTION_REGbits.PS0=0;
    OPTION_REGbits.PS1=0;
    OPTION_REGbits.PS2=0;
    
    while(1);
    
            
}
